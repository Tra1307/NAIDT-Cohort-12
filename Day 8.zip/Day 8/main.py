file_path = 'C:/Users/NCAIR/Desktop/Day 8/file.txt'
with open(file_path, mode = 'a') as file:
    file.write('\nThis is a new file')
  

'''
file = open(file_path)
contents = file.read()
print(contents)
file.close()
'''
