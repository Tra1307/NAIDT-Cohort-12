import datetime
day = datetime.datetime.now().day
month = datetime.datetime.now().month
year = datetime.datetime.now().year

print(f'{day}-{month}-{year}')



'''
random_integer = random.randint(0,6)
print('Random integer:', random_integer)
'''






















